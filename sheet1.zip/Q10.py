
a = "23 54 12#98 3 17"
print(a)
num= input("input frm a in above fashion: ")
spa = num.split(',')
x= int(list(spa[0],spa[1],spa[2]))
y=int(list(spa[4],spa[5],spa[6]))
print("list: ",x)
print("list: ",y)
