keys = input("enter keys: ")
values = (input("enter values: ")
x=dict(zip(keys,values))
print(x)

    
