a = [1,2,[3,4],[5,[100,200,['hello']],23,11],1,7]
b= print(a[3][1][2][0])
a.insert(0,'Nice to have it')
print(a)
a.append('here')
print(a)
