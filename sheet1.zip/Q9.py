d = {Student: ['Rahul’, ‘Kishore’, ‘Vidhya’, ‘Raakhi’], 
Marks: [57,87,67,79]}
for max(Marks) in d:
    print(student)
    
